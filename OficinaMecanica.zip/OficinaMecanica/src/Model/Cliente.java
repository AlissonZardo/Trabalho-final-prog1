/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;


/**
 *
 * @author aliss
 */
public class Cliente extends Pessoa{
    protected String endereco;
    protected String carro;

    public Cliente(String endereco, String carro, int id, String nome, String dataNasc, String telefone, String email, String rg) {
        super(id, nome, dataNasc, telefone, email, rg);
        this.endereco = endereco;
        this.carro = carro;
    }

    public Cliente(String endereco, String carro, int id, String nome) {
        super(id, nome);
        this.endereco = endereco;
        this.carro = carro;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getCarro() {
        return carro;
    }

    public void setCarro(String carro) {
        this.carro = carro;
    }

    
}
